const dgraph = require("./controllers/dgraph-graphql");
const schema = require("./schema");

dgraph.updateSchema(schema).then( s => {
  console.log("Schema updated successfully")
}).catch( e => {
  console.log(e)
});
